import React, { useState } from "react";

function Header() {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <header className="fixed top-0 left-0 w-full bg-white/80 backdrop-blur-md shadow-sm z-50">
            <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">

                {/* Logo */}
                <div className="flex items-center space-x-2">
                    <div className="bg-blue-600 text-white w-10 h-10 flex items-center justify-center rounded-lg font-bold text-lg">
                        HJ
                    </div>
                    <span className="text-2xl font-bold text-gray-900">Portfolio</span>
                </div>

                {/* Navigation (Desktop) */}
                <nav className="hidden md:flex items-center space-x-8 text-gray-700 font-medium">
                    <a href="#about" className="hover:text-blue-600 transition">About</a>
                    <a href="projects" className="hover:text-blue-600 transition">Work</a>
                    <a href="#testimonials" className="hover:text-blue-600 transition">Testimonials</a>
                    <a href="contact" className="hover:text-blue-600 transition">Contact</a>
                </nav>

                {/* Right Section */}
                <div className="flex items-center space-x-4">
                    <a
                        href="/My_Resume.pdf"
                        download
                        className="bg-gray-900 text-white px-4 py-2 rounded-lg font-medium hover:bg-gray-800 transition shadow hidden md:inline-block"
                    >
                        Download CV
                    </a>

                    {/* Mobile Menu Button */}
                    <button
                        className="md:hidden p-2 rounded-lg bg-gray-100 hover:bg-gray-200 transition"
                        onClick={() => setIsOpen(!isOpen)}
                    >
                        {isOpen ? (
                            <span className="text-2xl">✖</span>
                        ) : (
                            <span className="text-2xl">☰</span>
                        )}
                    </button>
                </div>
            </div>

            {/* Mobile Menu */}
            {isOpen && (
                <div className="md:hidden bg-white shadow-lg px-6 py-4 space-y-4 text-gray-700 font-medium">
                    <a href="#about" className="block hover:text-blue-600 transition">About</a>
                    <a href="#work" className="block hover:text-blue-600 transition">Work</a>
                    <a href="#testimonials" className="block hover:text-blue-600 transition">Testimonials</a>
                    <a href="#contact" className="block hover:text-blue-600 transition">Contact</a>
                    <a
                        href="/cv.pdf"
                        download
                        className="block bg-gray-900 text-white px-4 py-2 rounded-lg font-medium hover:bg-gray-800 transition shadow text-center"
                    >
                        Download CV
                    </a>
                </div>
            )}
        </header>
    );
}

export default Header;
